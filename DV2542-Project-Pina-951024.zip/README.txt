Steps to execute the code:
1. Launch Jupyter Notebook
2. Open data_analysis.ipynb
3. Run the notebook (optional)
4. Open modeling.ipynb
5. Run the notebook (optional)